[IN STATE OF DEVELOPMENT]

Got this fun idea to create Flappy Bird in OpenGL.

Changelog:
	
	04.02.2019 - Project created, collision are visible in console...
	05.02.2019 - Polished code, Restart on collision, Basic event system
